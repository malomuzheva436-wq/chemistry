import { getMolarMass } from "./MolarMass";
import { KolichestvoV } from './KolichestvoV';       // ← новый импорт
import { resultToVirtualRow } from './VirtualRow';  // ← для виртуальных строк

function normalizeText(value) {
  return String(value ?? '').trim().toLowerCase();
}

function parseNumericValue(value) {
  const normalized = String(value ?? '')
    .replace(/,/g, '.')
    .replace(/[^0-9.]/g, '');

  if (!normalized) return NaN;
  return Number(normalized);
}

function formatNumber(value) {
  return new Intl.NumberFormat('ru-RU', {
    maximumFractionDigits: 4,
  }).format(value);
}

export function Massa(danoRows = [], formula, findRow, givenRow) {
  const results = [];
  const errors = [];

  const normalizedFormula = normalizeText(formula);

  const rowsForFormula = danoRows.filter(
    (row) => normalizeText(row.formula) === normalizedFormula
  );

  if (rowsForFormula.length === 0) {
    errors.push(`Для вещества ${formula}: в блоке «Дано» нет данных.`);
    return { results, errors };
  }

  // ===== 1. Ищем количество вещества напрямую =====
  let kolRow =
    [...rowsForFormula]
      .reverse()
      .find((row) =>
        normalizeText(row.charText).includes('количество вещества')
      ) || null;

  const chainSteps = [];

  // ===== 2. ЕСЛИ НЕТ — пробуем получить через объём (вызываем KolichestvoV) =====
  if (!kolRow) {
    const kolAnswer = KolichestvoV(danoRows, formula, findRow, givenRow);

    if (kolAnswer.results.length > 0) {
      const virtualRow = resultToVirtualRow(
        kolAnswer.results[0],
        formula,
        'Количество вещества'
      );

      if (virtualRow) {
        kolRow = virtualRow;
        if (kolAnswer.results[0].text) {
          chainSteps.push(kolAnswer.results[0].text);
        }
      }
    }
  }

  if (!kolRow) {
    errors.push(
      `Для вещества ${formula}: в «Дано» нет количества вещества, и вычислить его через объём тоже не удалось.`
    );
    return { results, errors };
  }

  // ===== Дальше твой прежний код расчёта массы: m = n × M =====
  const n = parseNumericValue(kolRow.value);

  if (Number.isNaN(n) || n <= 0) {
    errors.push(
      `Для вещества ${formula}: количество вещества указано некорректно.`
    );
    return { results, errors };
  }

  const molarMass = Number(getMolarMass(formula));

  if (Number.isNaN(molarMass) || molarMass <= 0) {
    errors.push(
      `Для вещества ${formula}: молярная масса не найдена в словаре.`
    );
    return { results, errors };
  }

  const mass = n * molarMass;
  const roundedMass = Number(mass.toFixed(4));

  // Формируем итоговый текст с цепочкой шагов
  const finalStep = `m(${formula}) = n(${formula}) × M(${formula}) = ${formatNumber(
    n
  )} моль × ${formatNumber(molarMass)} г/моль = ${formatNumber(
    roundedMass
  )} г`;

  const fullText = [...chainSteps, finalStep].join(' → ');

  results.push({
    id: `massa-${formula}`,
    formula,
    n,
    molarMass,
    mass: roundedMass,
    massUnit: 'г',
    text: fullText,
  });

  return {
    results,
    errors,
  };
}