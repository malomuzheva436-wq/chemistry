import { parseScientificValue } from "./DliaMolekul";


function formatNumber(value) {
  if (!Number.isFinite(value)) {
    return '';
  }
  if (value === 0) {
    return '0';
  }

  const abs = Math.abs(value);

  if (abs >= 1_000_000 || abs < 0.000001) {
    return value.toExponential(4).replace('.', ',');
  }

  return new Intl.NumberFormat('ru-RU', {
    maximumFractionDigits: 4,
  }).format(value);
}


export function KolichestvoN(danoRows = []) {
  const results = [];
  const errors = [];
  const Na=6.022e23;

  if (!Array.isArray(danoRows) || danoRows.length === 0) {
    errors.push('Данные отсутствуют. Добавьте количество молекул.');

    return {
      results,
      errors,
    };
  }

  // Собираем только строки, где указано количество молекул
  const molekulaRowsByFormula = new Map();

  danoRows.forEach((row) => {
    const formula = String(row.formula ?? '').trim();

    if (!formula) {
      return;
    }


    // Если для одной формулы добавили несколько количеств молекул,
    // будет использована последняя добавленная строка
    molekulaRowsByFormula.set(formula, row);
  });

  if (molekulaRowsByFormula.size === 0) {
    errors.push(
      'Для расчёта количества вещества нужно добавить количество молекул.'
    );

    return {
      results,
      errors,
    };
  }

  molekulaRowsByFormula.forEach((row, formula) => {
    const molekula = parseScientificValue(row.value);

    if (Number.isNaN(molekula)) {
      errors.push(
        `Для вещества ${formula}: количество молекул указано некорректно.`
      );

      return;
    }

    if (molekula <= 0) {
      errors.push(
        `Для вещества ${formula}: количество молекул должно быть больше нуля.`
      );

      return;
    }

    const amount = molekula / Na;

    const roundedAmount = Number(amount.toFixed(4));

    results.push({
      id: formula,
      formula,
      molekula,
      Na,
      amount: roundedAmount,
      text: `n(${formula}) = ${formatNumber(molekula)}*10^23/${formatNumber(
        Na
      )} = ${formatNumber(roundedAmount)}`,
    });
  });

  return {
    results,
    errors,
  };
}