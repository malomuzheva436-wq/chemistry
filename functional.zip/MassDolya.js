function normalizeText(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/ё/g, 'е');
}

function parseNumericValue(value) {
  const normalized = String(value ?? '')
    .replace(/,/g, '.')
    .replace(/[^0-9.]/g, '');

  if (!normalized) {
    return NaN;
  }

  return Number(normalized);
}

function formatNumber(value) {
  return new Intl.NumberFormat('ru-RU', {
    maximumFractionDigits: 4,
  }).format(value);
}

// Переводим массу в граммы
function convertMassToGrams(value, unit) {
  const normalizedUnit = normalizeText(unit);

  if (normalizedUnit === 'кг') {
    return value * 1000;
  }

  if (normalizedUnit === 'мг') {
    return value / 1000;
  }

  return value; // уже граммы
}

export function MassDolya(danoRows = [], formula, findRow, givenRow) {
  const results = [];
  const errors = [];

  const normalizedFormula = normalizeText(formula);

  const rowsForFormula = danoRows.filter(
    (row) => normalizeText(row.formula) === normalizedFormula
  );

  if (rowsForFormula.length === 0) {
    errors.push(`Для вещества ${formula}: в блоке «Дано» нет данных.`);

    return { results, errors };
  }

  // Ищем строку с массой вещества
  const massRow =
    [...rowsForFormula]
      .reverse()
      .find((row) =>
        normalizeText(row.charText).includes('масса вещества')
      ) || null;

  // ===== Ищем строку с массой раствора (смеси) =====
  // Сначала для той же формулы, а если нет — любую в «Дано»
  const solutionRow =
    [...rowsForFormula]
      .reverse()
      .find((row) =>
        normalizeText(row.charText).includes('масса раствора')
      ) ||
    [...danoRows]
      .reverse()
      .find((row) =>
        normalizeText(row.charText).includes('масса раствора')
      ) ||
    null;

  if (!massRow) {
    errors.push(
      `Для вещества ${formula}: в «Дано» нет массы вещества. Добавьте её, чтобы рассчитать массовую долю.`
    );

    return { results, errors };
  }

  if (!solutionRow) {
    errors.push(
      `Для вещества ${formula}: в «Дано» нет массы раствора (смеси). Добавьте её, чтобы рассчитать массовую долю.`
    );

    return { results, errors };
  }

  // Масса вещества
  const mass = parseNumericValue(massRow.value);

  if (Number.isNaN(mass) || mass <= 0) {
    errors.push(
      `Для вещества ${formula}: масса вещества указана некорректно.`
    );

    return { results, errors };
  }

  // Масса раствора (смеси)
  const solutionMass = parseNumericValue(solutionRow.value);

  if (Number.isNaN(solutionMass) || solutionMass <= 0) {
    errors.push(
      `Для вещества ${formula}: масса раствора (смеси) указана некорректно.`
    );

    return { results, errors };
  }

  // Переводим обе массы в граммы
  const massInGrams = convertMassToGrams(mass, massRow.izmerenie);
  const solutionMassInGrams = convertMassToGrams(
    solutionMass,
    solutionRow.izmerenie
  );

  // Масса вещества не может быть больше массы раствора (смеси)
  if (massInGrams > solutionMassInGrams) {
    errors.push(
      `Для вещества ${formula}: масса вещества не может быть больше массы раствора (смеси).`
    );

    return { results, errors };
  }

  const dolya = massInGrams / solutionMassInGrams;

  // Учитываем, в каких единицах просят ответ в блоке «Найти»
  const requestedUnit = normalizeText(findRow?.izmerenie);

  let value;
  let outputUnit;

  if (requestedUnit === '%' || requestedUnit === '') {
    value = dolya * 100;
    outputUnit = '%';
  } else {
    // просто доля: 0,1
    value = dolya;
    outputUnit = '';
  }

  const roundedValue = Number(value.toFixed(4));

  const text =
    outputUnit === '%'
      ? `w(${formula}) = m(${formula}) / m(раствора) = ${formatNumber(
          massInGrams
        )} г / ${formatNumber(solutionMassInGrams)} г = ${formatNumber(
          dolya
        )} = ${formatNumber(roundedValue)} %`
      : `w(${formula}) = m(${formula}) / m(раствора) = ${formatNumber(
          massInGrams
        )} г / ${formatNumber(solutionMassInGrams)} г = ${formatNumber(
          roundedValue
        )}`;

  results.push({
    id: `massDolya-${formula}`,
    formula,
    massVeshchestva: mass,
    massVeshchestvaUnit: massRow.izmerenie || 'г',
    massaRastvora: solutionMass,
    massaRastvoraUnit: solutionRow.izmerenie || 'г',
    massovayaDolya: roundedValue,
    massovayaDolyaUnit: outputUnit,
    text,
  });

  return {
    results,
    errors,
  };
}