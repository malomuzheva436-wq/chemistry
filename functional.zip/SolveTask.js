import { KolichestvoM } from './KolichestvoM';
import { KolichestvoV } from './KolichestvoV';
import { KolichestvoN } from './KolichestvoN';
import { Massa } from './Massa';
import { Obyom } from './Obyom';
import { ObyomP } from './ObyomP';
import { MassaR } from './MassaR';
import { MassaRVoda } from './MassaRVoda';
import { MassaRP } from './MassaRP';
import { MassaW } from './MassaW';
import { MassDolya } from './MassDolya';

// Максимальное количество пунктов в блоке "Найти"
const MAX_NAYTI_ITEMS = 3;

// ===== Вспомогательные функции =====

function normalizeText(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/ё/g, 'е');
}

function isMassGiven(row) {
  return normalizeText(row.charText).includes('масса вещества');
}

function isVolumeGiven(row) {
  return normalizeText(row.charText).includes('объем');
}

function isMoleculesGiven(row) {
  return (normalizeText(row.charText).includes('молекул'));
}

function isKolGiven(row) {
  return (normalizeText(row.charText).includes('количество вещества'));
}

function isDolyaGiven(row) {
  return normalizeText(row.charText).includes('массовая доля');
}

function isRastvorGiven(row){
  return normalizeText(row.charText).includes('масса раствора');
} 

// Вода: либо «Масса вещества: H2O», либо отдельная «Масса воды»
function isWaterGiven(row) {
  const char = normalizeText(row.charText);
  const rowFormula = normalizeText(row.formula);

  return (
    char.includes('масса воды') ||
    (char.includes('масса вещества') &&
      (rowFormula === 'h2o' || rowFormula === 'вода'))
  );
}

function isObyomGiven(row) {
  const char = normalizeText(row.charText);

  return char.includes('объем') || char.includes('объём');
}

function isDensityGiven(row) {
  return normalizeText(row.charText).includes('плотность');
}

function findLastByCondition(rows, condition) {
  return [...rows].reverse().find(condition) || null;
}

// ===== Приведение ответа от функций расчёта к одному виду =====
function normalizeAnswer(answer, solverName, formula) {
  if (!answer) {
    return {
      results: [],
      errors: [`Функция ${solverName} не вернула результат.`],
    };
  }

  // Если функция вернула просто строку или число
  if (typeof answer === 'string' || typeof answer === 'number') {
    return {
      results: [
        {
          id: `${solverName}-${formula}`,
          formula,
          text: String(answer),
        },
      ],
      errors: [],
    };
  }

  // Если функция вернула массив результатов
  if (Array.isArray(answer)) {
    const results = answer.map((item, index) => {
      if (typeof item === 'object' && item !== null) {
        return {
          id: item.id ?? `${solverName}-${formula}-${index}`,
          formula,
          ...item,
        };
      }

      return {
        id: `${solverName}-${formula}-${index}`,
        formula,
        text: String(item),
      };
    });

    return {
      results,
      errors: [],
    };
  }

  // Если функция вернула объект
  if (typeof answer === 'object') {
    const results = [];
    const errors = [];

    if (Array.isArray(answer.results)) {
      answer.results.forEach((item, index) => {
        if (typeof item === 'object' && item !== null) {
          results.push({
            id: item.id ?? `${solverName}-${formula}-${index}`,
            formula,
            ...item,
          });
        } else {
          results.push({
            id: `${solverName}-${formula}-${index}`,
            formula,
            text: String(item),
          });
        }
      });
    }

    if (Array.isArray(answer.errors)) {
      errors.push(...answer.errors.map(String));
    }

    if (answer.error !== undefined) {
      errors.push(String(answer.error));
    }

    if (results.length === 0) {
      if (answer.text !== undefined) {
        results.push({
          id: `${solverName}-${formula}`,
          formula,
          text: String(answer.text),
        });
      } else if (answer.result !== undefined) {
        const nested = normalizeAnswer(answer.result, solverName, formula);

        results.push(...nested.results);
        errors.push(...nested.errors);
      }
    }

    if (results.length > 0 || errors.length > 0) {
      return {
        results,
        errors,
      };
    }
  }

  return {
    results: [],
    errors: [`Не удалось распознать ответ функции ${solverName}.`],
  };
}

// ===== Безопасный вызов функции расчёта =====

function callSolver(solver, solverName, payload) {
  if (typeof solver !== 'function') {
    return {
      results: [],
      errors: [`Функция ${solverName} не подключена.`],
    };
  }

  try {
    // Если твои функции принимают другой набор аргументов,
    // поменяй эту строку под свой формат.
    //
    // Сейчас функция расчёта получает:
    //
    // danoRows  - все данные из блока "Дано"
    // formula   - формула вещества из блока "Найти"
    // findRow   - сама строка из блока "Найти"
    // givenRow  - конкретная строка из блока "Дано",
    //             которая стала основанием для выбора функции
    //
    const answer = solver(
      payload.danoRows,
      payload.formula,
      payload.findRow,
      payload.givenRow
    );

    return normalizeAnswer(answer, solverName, payload.formula);
  } catch (error) {
    return {
      results: [],
      errors: [
        `Ошибка при вызове функции ${solverName}: ${error.message}`,
      ],
    };
  }
}

// Диспетчер для поиска количества вещества

function resolveKol({ danoRows, formula, findRow }) {
  const normalizedFormula = normalizeText(formula);

  const rowsForFormula = danoRows.filter(
    (row) => normalizeText(row.formula) === normalizedFormula
  );

  if (rowsForFormula.length === 0) {
    return {
      results: [],
      errors: [`Для вещества ${formula}: в блоке «Дано» нет данных.`],
    };
  }

  const massRow = findLastByCondition(rowsForFormula, isMassGiven);
  const volumeRow = findLastByCondition(rowsForFormula, isVolumeGiven);
  const moleculesRow = findLastByCondition(rowsForFormula,isMoleculesGiven);
  const rastvorRow = findLastByCondition(rowsForFormula, isRastvorGiven);
  const dolyaRow = findLastByCondition(rowsForFormula, isDolyaGiven);

  const payload = {
    danoRows,
    formula,
    findRow,
    rowsForFormula,
  };

  if (massRow || (rastvorRow && dolyaRow)) {
  return callSolver(KolichestvoM, 'KolichestvoM', {
    ...payload,
    givenRow: massRow,
  });
  }

  if (volumeRow) {
    return callSolver(KolichestvoV, 'KolichestvoV', {
      ...payload,
      givenRow: volumeRow,
    });
  }

  if (moleculesRow) {
    return callSolver(KolichestvoN, 'KolichestvoN', {
      ...payload,
      givenRow: moleculesRow,
    });
  }

  return {
    results: [],
    errors: [
      `Для вещества ${formula}: чтобы найти количество вещества, добавьте в «Дано» массу вещества, объём вещества или количество молекул.`,
    ],
  };
}

//Диспетчер для поиска массы вещества
function resolveMass({ danoRows, formula, findRow }) {
  const normalizedFormula = normalizeText(formula);

  const rowsForFormula = danoRows.filter(
    (row) => normalizeText(row.formula) === normalizedFormula
  );
  if (rowsForFormula.length === 0) {
    return {
      results: [],
      errors: [`Для вещества ${formula}: в блоке «Дано» нет данных.`],
    };
  }

  const kolRow = findLastByCondition(rowsForFormula, isKolGiven);
  const massaR = findLastByCondition(rowsForFormula, isRastvorGiven);
  const omegaRow = findLastByCondition(rowsForFormula, isDolyaGiven);
  const payload = {
    danoRows,
    formula,
    findRow,
    rowsForFormula,
  };

  if (kolRow) {
    return callSolver(Massa, 'Massa', {
      ...payload,
      givenRow: kolRow,
    });
  }

  if (massaR && omegaRow) {
    return callSolver(MassaW, 'MassaW', {
      ...payload,
      givenRow: massaR,
    });
  }
  
  return {
    results: [],
    errors: [
      `Для вещества ${formula}: чтобы найти массу вещества, добавьте в «Дано» количество вещества.`,
    ],
  };
}

//Диспетчер для поиска объёма
function resolveObyom({ danoRows, formula, findRow }) {
  const normalizedFormula = normalizeText(formula);

  const rowsForFormula = danoRows.filter(
    (row) => normalizeText(row.formula) === normalizedFormula
  );
  if (rowsForFormula.length === 0) {
    return {
      results: [],
      errors: [`Для вещества ${formula}: в блоке «Дано» нет данных.`],
    };
  }

  const kolRow = findLastByCondition(rowsForFormula, isKolGiven);
  const rastvorRow = findLastByCondition(rowsForFormula, isRastvorGiven);
  const densityRow =
  findLastByCondition(rowsForFormula, isDensityGiven) ||
  findLastByCondition(danoRows, isDensityGiven);

  const payload = {
    danoRows,
    formula,
    findRow,
    rowsForFormula,
  };

  if (kolRow) {
    return callSolver(Obyom, 'Obyom', {
      ...payload,
      givenRow: kolRow,
    });
  }

  if (rastvorRow && densityRow) {
  return callSolver(ObyomP, 'ObyomP', {
    ...payload,
    givenRow: rastvorRow,
  });
}
  return {
    results: [],
    errors: [
      `Для вещества ${formula}: чтобы найти объём вещества, добавьте в «Дано» количество вещества.`,
    ],
  };
}

// ===== Диспетчер для поиска массы раствора =====
function resolveMassR({ danoRows, formula, findRow }) {
  const normalizedFormula = normalizeText(formula);

  const rowsForFormula = danoRows.filter(
    (row) => normalizeText(row.formula) === normalizedFormula
  );

  if (rowsForFormula.length === 0) {
    return {
      results: [],
      errors: [`Для вещества ${formula}: в блоке «Дано» нет данных.`],
    };
  }

  const massRow = findLastByCondition(rowsForFormula, isMassGiven);
  const dolyaRow = findLastByCondition(rowsForFormula, isDolyaGiven);
  const waterRow = findLastByCondition(danoRows, isWaterGiven);
  const volumeRow = findLastByCondition(rowsForFormula, isObyomGiven);
  const densityRow =
    findLastByCondition(rowsForFormula, isDensityGiven) ||
    findLastByCondition(danoRows, isDensityGiven);

  const payload = {
    danoRows,
    formula,
    findRow,
    rowsForFormula,
  };

  // Вариант 1: масса вещества + массовая доля
  // m(раствора) = m(вещества) / w
  if (massRow && dolyaRow) {
    return callSolver(MassaR, 'MassaR', {
      ...payload,
      givenRow: massRow,
    });
  }

  // Вариант 2: масса вещества + масса воды
  // m(раствора) = m(вещества) + m(воды)
  if (massRow && waterRow) {
    return callSolver(MassaRVoda, 'MassaRVoda', {
      ...payload,
      givenRow: massRow,
    });
  }

  // Вариант 3: объём + плотность
  // m(раствора) = ρ × V
  if (volumeRow && densityRow) {
    return callSolver(MassaRP, 'MassaRP', {
      ...payload,
      givenRow: volumeRow,
    });
  }

  // Если данных не хватает — объясняем, что добавить
  const missing = [];

  if (!massRow && !volumeRow) {
    missing.push('массу вещества или объём раствора');
  }

  if (!dolyaRow && !waterRow && !densityRow) {
    missing.push('массовую долю, массу воды или плотность');
  }

  return {
    results: [],
    errors: [
      `Для вещества ${formula}: чтобы найти массу раствора, добавьте в «Дано» ${missing.join(' и ')}.`,
    ],
  };
}

// ===== Главная функция solveTask =====

export function SolveTask({ danoRows = [], naytiRows = [] }) {
  const results = [];
  const errors = [];

  // Проверяем, есть ли вообще запрос в "Найти"
  if (!naytiRows.length) {
    errors.push('Добавьте в «Найти», что нужно найти.');

    return {
      results,
      errors,
    };
  }

  // Ограничение: не более 3 пунктов в "Найти"
  if (naytiRows.length > MAX_NAYTI_ITEMS) {
    errors.push(
      `В блоке «Найти» может быть не более ${MAX_NAYTI_ITEMS} пунктов.`
    );

    return {
      results,
      errors,
    };
  }

  // Проверяем, есть ли данные в "Дано"
  if (!danoRows.length) {
    errors.push('Данные отсутствуют. Заполните «Дано».');

    return {
      results,
      errors,
    };
  }

  // Обрабатываем каждый пункт из "Найти"
  naytiRows.forEach((findRow, index) => {
    const target = normalizeText(findRow.charText);
    const formula = String(findRow.formula ?? '').trim();

    if (!formula) {
      errors.push(
        `В «Найти» строка ${index + 1}: не указана формула вещества.`
      );

      return;
    }

    let answer;

    // ===== Что именно требуется найти =====

    if (target.includes('количество вещества')) {
      // Если нужно найти количество вещества,
      // выбираем одну из трёх функций в зависимости от того,
      // что указано в "Дано".
      answer = resolveKol({
        danoRows,
        formula,
        findRow,
      });
    } else if (target.includes('масса вещества')) {
      answer=resolveMass({
        danoRows,
        formula,
        findRow,
      });
    } else if (target.includes('объем')) {
      answer=resolveObyom({
        danoRows,
        formula,
        findRow,
      });
    } else if (target.includes('масса раствора')) {
        answer = resolveMassR({ 
          danoRows, 
          formula, 
          findRow 
        });
    } else if (target.includes('массовая доля')) {
      answer = callSolver(MassDolya, 'MassDolya', {
        danoRows,
        formula,
        findRow,
        givenRow: null,
      });
    } else {
      errors.push(
        `Неизвестный запрос в «Найти»: ${findRow.charText}.`
      );

      return;
    }

    // Если функция расчёта вернула результаты — добавляем их
    if (answer.results.length > 0) {
      answer.results.forEach((result, resultIndex) => {
        results.push({
          ...result,
          id: `find-${findRow.id ?? index}-${
            result.id ?? resultIndex
          }`,
        });
      });
    }

    // Если функция расчёта вернула ошибки — добавляем их
    if (answer.errors.length > 0) {
      errors.push(...answer.errors);
    }
  });

  return {
    results,
    errors: [...new Set(errors)],
  };
}