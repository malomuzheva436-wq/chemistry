export const FORMULA_VALUES = [
  'NaCl',
  'LiCl',
  'LiBr',
  'CuSO4',
  'H2O',
  'CO2',
  'N2',
];

const UNITS_BY_CHARACTERISTIC = {
  'масса вещества': ['кг', 'г', 'мг'],
  'количество вещества': ['моль'],
  'объём': ['м³', 'л', 'мл'],
  'масса раствора': ['кг', 'г'],
  'количество молекул': ['молекула'],
  'плотность': ['г/мл'],
  'массовая доля': ['%'],
};

export const UNITS = [
  'кг',
  'г',
  'моль',
  'м³',
  'л',
  'мл',
  'молекула',
  '%',
  'г/мл',
];

export const CHARACTERISTICS = [
  {
    value: 'масса вещества',
    label: 'Масса вещества',
  },
  {
    value: 'количество вещества',
    label: 'Количество вещества',
  },
  {
    value: 'объём',
    label: 'Объём',
  },
  {
    value: 'масса раствора',
    label: 'Масса раствора',
  },
  {
    value: 'количество молекул',
    label: 'Количество молекул',
  },
  {
    value: 'плотность',
    label: 'Плотность',
  },
  {
    value: 'массовая доля',
    label: 'Массовая доля',
  },
];

export function getCharacteristicLabel(value) {
  const characteristic = CHARACTERISTICS.find((item) => item.value === value);

  return characteristic ? characteristic.label : '';
}
// ===== Новая функция: возвращает единицы для выбранной характеристики =====
export function getUnitsForCharacteristic(characteristica) {
  return UNITS_BY_CHARACTERISTIC[characteristica] || [];
}