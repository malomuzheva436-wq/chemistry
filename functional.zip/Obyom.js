function normalizeText(value) {
  return String(value ?? '').trim().toLowerCase();
}

function parseNumericValue(value) {
  const normalized = String(value ?? '')
    .replace(/,/g, '.')
    .replace(/[^0-9.]/g, '');

  if (!normalized) return NaN;
  return Number(normalized);
}

function formatNumber(value) {
  return new Intl.NumberFormat('ru-RU', {
    maximumFractionDigits: 4,
  }).format(value);
}

// Функция теперь принимает 4 аргумента, которые передает solveTask
export function Obyom(danoRows = [], formula, findRow, givenRow) {
  const results = [];
  const errors = [];
  const Vm=22.4;

  // 1. Берем строку с количеством вещества, которую нашел solveTask (givenRow)
  let kolRow = givenRow;

  // На всякий случай, если givenRow не передался, ищем сами
  if (!kolRow) {
    const normalizedFormula = normalizeText(formula);
    kolRow = danoRows.find(
      (row) =>
        normalizeText(row.formula) === normalizedFormula &&
        normalizeText(row.charText).includes('количество вещества')
    );
  }

  if (!kolRow) {
    errors.push(`Для вещества ${formula}: в «Дано» не указано количество вещества.`);
    return { results, errors };
  }

  // 2. Парсим количество вещества (n)
  const n = parseNumericValue(kolRow.value);

  if (Number.isNaN(n) || n <= 0) {
    errors.push(`Для вещества ${formula}: количество вещества указано некорректно.`);
    return { results, errors };
  }

  // 3. Считаем объём 
  let V = n * Vm;
  let outputUnit = 'л';

  // 5. Проверяем, в каких единицах просят ответ в блоке "Найти" (findRow.izmerenie)
  const requestedUnit = normalizeText(findRow?.izmerenie);

  if (requestedUnit === 'мл') {
    V = V * 1000;
    outputUnit = 'мл';
  }
  if (requestedUnit === 'м³') {
    V = V/1000;
    outputUnit = 'м³';
  }

  const roundedV = Number(V.toFixed(4));

  // 6. Формируем правильный результат
  results.push({
    id: `V-${formula}`,
    formula,
    n,
    Vm,
    V: roundedV,
    massUnit: outputUnit,
    // Правильный текст решения: V = n * Vm
    text: `V(${formula}) = n(${formula}) × Vm = ${formatNumber(
      n
    )} моль × ${formatNumber(Vm)} моль/л = ${formatNumber(
      roundedV
    )} ${outputUnit}`,
  });

  return {
    results,
    errors,
  };
}