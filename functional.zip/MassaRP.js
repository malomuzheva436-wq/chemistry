function normalizeText(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/ё/g, 'е');
}

function parseNumericValue(value) {
  const normalized = String(value ?? '')
    .replace(/,/g, '.')
    .replace(/[^0-9.]/g, '');

  if (!normalized) {
    return NaN;
  }

  return Number(normalized);
}

function formatNumber(value) {
  return new Intl.NumberFormat('ru-RU', {
    maximumFractionDigits: 4,
  }).format(value);
}

// Переводим объём в миллилитры
function convertVolumeToMl(value, unit) {
  const normalizedUnit = normalizeText(unit);

  if (normalizedUnit === 'л') {
    return value * 1000;
  }

  if (normalizedUnit === 'м³' || normalizedUnit === 'м3') {
    return value * 1000000;
  }

  return value; // уже миллилитры
}

// SolveTask вызывает функцию с аргументами:
// (danoRows, formula, findRow, givenRow)
export function MassaRP(danoRows = [], formula, findRow, givenRow) {
  const results = [];
  const errors = [];

  const normalizedFormula = normalizeText(formula);

  const rowsForFormula = danoRows.filter(
    (row) => normalizeText(row.formula) === normalizedFormula
  );

  if (rowsForFormula.length === 0) {
    errors.push(`Для вещества ${formula}: в блоке «Дано» нет данных.`);

    return { results, errors };
  }

  // ===== Ищем строку с объёмом =====
  const volumeRow =
    [...rowsForFormula]
      .reverse()
      .find((row) => normalizeText(row.charText).includes('объем')) || null;

  // ===== Ищем строку с плотностью =====
  // Сначала для той же формулы, а если нет — любую в «Дано»
  const densityRow =
    [...rowsForFormula]
      .reverse()
      .find((row) => normalizeText(row.charText).includes('плотность')) ||
    [...danoRows]
      .reverse()
      .find((row) => normalizeText(row.charText).includes('плотность')) ||
    null;

  if (!volumeRow) {
    errors.push(
      `Для вещества ${formula}: в «Дано» нет объёма. Добавьте его, чтобы рассчитать массу раствора.`
    );

    return { results, errors };
  }

  if (!densityRow) {
    errors.push(
      `Для вещества ${formula}: в «Дано» нет плотности. Добавьте её, чтобы рассчитать массу раствора.`
    );

    return { results, errors };
  }

  // ===== Объём =====
  const volume = parseNumericValue(volumeRow.value);

  if (Number.isNaN(volume) || volume <= 0) {
    errors.push(`Для вещества ${formula}: объём указан некорректно.`);

    return { results, errors };
  }

  // ===== Плотность =====
  const density = parseNumericValue(densityRow.value);

  if (Number.isNaN(density) || density <= 0) {
    errors.push(`Для вещества ${formula}: плотность указана некорректно.`);

    return { results, errors };
  }

  // Переводим объём в миллилитры, так как плотность в г/мл
  const volumeInMl = convertVolumeToMl(volume, volumeRow.izmerenie);

  // m(раствора) = ρ × V
  let solutionMassInGrams = density * volumeInMl;
  let outputUnit = 'г';

  // Учитываем, в каких единицах просят ответ в блоке «Найти»
  const requestedUnit = normalizeText(findRow?.izmerenie);

  if (requestedUnit === 'кг') {
    solutionMassInGrams = solutionMassInGrams / 1000;
    outputUnit = 'кг';
  } else if (requestedUnit === 'мг') {
    solutionMassInGrams = solutionMassInGrams * 1000;
    outputUnit = 'мг';
  }

  const roundedMass = Number(solutionMassInGrams.toFixed(4));

  // Если объём пришлось переводить в мл, показываем это в решении
  const volumeText =
    volumeInMl !== volume
      ? `${formatNumber(volume)} ${volumeRow.izmerenie} = ${formatNumber(volumeInMl)} мл`
      : `${formatNumber(volumeInMl)} мл`;

  results.push({
    id: `massaRP-${formula}`,
    formula,
    plotnost: density,
    plotnostUnit: densityRow.izmerenie || 'г/мл',
    obyom: volume,
    obyomUnit: volumeRow.izmerenie || 'мл',
    obyomMl: volumeInMl,
    massaRastvora: roundedMass,
    massaRastvoraUnit: outputUnit,
    text: `m(раствора) = ρ × V = ${formatNumber(
      density
    )} г/мл × ${volumeText} = ${formatNumber(roundedMass)} ${outputUnit}`,
  });

  return {
    results,
    errors,
  };
}