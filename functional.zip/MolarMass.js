// Словарь молярных масс
// Ключ — формула вещества
// Значение — молярная масса в г/моль

export const MolarMass = {
  //неорганика
  //простые вещества
  H2:2, 
  He:4,
  Li:7,
  Be:9,
  B:11,
  C:12,
  N2:28,
  O2:32,
  F2:38,
  Ne:20,
  Na:23,
  Mg:24,
  Al:27,
  Si:28,
  P:31,
  S:32,
  Cl2:70,
  Ar:40,
  K:39,
  Ca:40,
  Ti:48,
  Cr:52,
  Mn:55,
  Fe:56,
  Co:59,
  Ni:59,
  Cu:64,
  Zn:65,
  As:75,
  Br:80,
  Ag:108,
  Sn:119,
  I2:254,
  Ba:137,
  Au:197,
  Hg:201,
  Pb:207,
  //оксиды
  H2O:18,
  Li2O:30,
  K2O:94,
  BaO:153,
  CaO:56,
  Na2O:62,
  MgO:40,
  BeO:25,
  Al2O3:102,
  MnO:71,
  ZnO:81,
  CrO:68,
  Cr2O3:152,
  FeO:72,
  Fe2O3:160,
  CoO:75,
  Co2O3:166,
  NiO:75,
  SnO:135,
  PbO:223,
  CuO:80,
  Cu2O:144,
  Ag2O:232,
  HgO:217,
  CO:28,
  CO2:44,
  SiO2:60,
  SO2:64,
  SO3:80,
  P2O5:142,
  N2O5:108,
  N2O3:76,
  NO2:46,
  NO:30,
  CrO3:100,
  Mn2O7:222,
  Cl2O7:183,
  //кислоты
  HF:20,
  HCl:36.5,
  HBr:81,
  HI:128,
  H2S:34,
  H2SO4:98,
  H2SO3:82,
  HClO4:100,
  HClO3:84,
  HNO3:63,
  HNO2:47,
  H3PO4:98,
  H2Cr2O7:218,
  HCrO4:118,
  HMnO4:120,
  H2CO3:62,
  H2SiO3:78,
  HCN:27,
  //основания
  NH4OH:35,
  LiOH:24,
  NaOH:40,
  KOH:56,
  //Ba'('OH')'2:171,
  //соли
  NaCl:58.5,
  LiCl:80.81,
  LiBr:86.85,
  CuSO4:159.61,
  
  CaCO3:100.09,
  AgNO3:169.87,
  BaCl2:208.23,
  KCl:74.55,
};

export function getMolarMass(formula) {
  const normalizedFormula = String(formula ?? '')
    .trim()
    .replace(/\s+/g, '');

  if (!normalizedFormula) {
    return null;
  }

  if (Object.prototype.hasOwnProperty.call(MolarMass, normalizedFormula)) {
    return MolarMass[normalizedFormula];
  }

  return null;
}