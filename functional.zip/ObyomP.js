// ObyomP.js
// Вычисление объёма раствора через массу раствора и плотность:
//
// V(раствора) = m(раствора) / ρ
//
// Плотность измеряется в г/мл,
// поэтому при делении объём получается в миллилитрах.

function normalizeText(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/ё/g, 'е');
}

function parseNumericValue(value) {
  const normalized = String(value ?? '')
    .replace(/,/g, '.')
    .replace(/[^0-9.]/g, '');

  if (!normalized) {
    return NaN;
  }

  return Number(normalized);
}

function formatNumber(value) {
  return new Intl.NumberFormat('ru-RU', {
    maximumFractionDigits: 4,
  }).format(value);
}

// Переводим массу раствора в граммы
function convertMassToGrams(value, unit) {
  const normalizedUnit = normalizeText(unit);

  if (normalizedUnit === 'кг') {
    return value * 1000;
  }

  if (normalizedUnit === 'мг') {
    return value / 1000;
  }

  return value; // уже граммы
}

// SolveTask вызывает функцию с аргументами:
// (danoRows, formula, findRow, givenRow)
export function ObyomP(danoRows = [], formula, findRow, givenRow) {
  const results = [];
  const errors = [];

  const normalizedFormula = normalizeText(formula);

  const rowsForFormula = danoRows.filter(
    (row) => normalizeText(row.formula) === normalizedFormula
  );

  if (rowsForFormula.length === 0) {
    errors.push(`Для вещества ${formula}: в блоке «Дано» нет данных.`);

    return { results, errors };
  }

  // ===== Ищем строку с массой раствора =====
  const rastvorRow =
    [...rowsForFormula]
      .reverse()
      .find((row) =>
        normalizeText(row.charText).includes('масса раствора')
      ) || null;

  // ===== Ищем строку с плотностью =====
  // Сначала для той же формулы, а если нет — любую в «Дано»
  const densityRow =
    [...rowsForFormula]
      .reverse()
      .find((row) => normalizeText(row.charText).includes('плотность')) ||
    [...danoRows]
      .reverse()
      .find((row) => normalizeText(row.charText).includes('плотность')) ||
    null;

  if (!rastvorRow) {
    errors.push(
      `Для вещества ${formula}: в «Дано» нет массы раствора. Добавьте её, чтобы рассчитать объём.`
    );

    return { results, errors };
  }

  if (!densityRow) {
    errors.push(
      `Для вещества ${formula}: в «Дано» нет плотности. Добавьте её, чтобы рассчитать объём.`
    );

    return { results, errors };
  }

  // ===== Масса раствора =====
  const mass = parseNumericValue(rastvorRow.value);

  if (Number.isNaN(mass) || mass <= 0) {
    errors.push(
      `Для вещества ${formula}: масса раствора указана некорректно.`
    );

    return { results, errors };
  }

  // ===== Плотность =====
  const density = parseNumericValue(densityRow.value);

  if (Number.isNaN(density) || density <= 0) {
    errors.push(`Для вещества ${formula}: плотность указана некорректно.`);

    return { results, errors };
  }

  // Переводим массу раствора в граммы
  const massInGrams = convertMassToGrams(mass, rastvorRow.izmerenie);

  // V(раствора) = m(раствора) / ρ → получаем миллилитры
  const volumeInMl = massInGrams / density;

  // Переводим в единицу, которую просят в блоке «Найти»
  const requestedUnit = normalizeText(findRow?.izmerenie);

  let volume = volumeInMl;
  let outputUnit = 'мл';

  if (requestedUnit === 'л') {
    volume = volumeInMl / 1000;
    outputUnit = 'л';
  } else if (requestedUnit === 'м³' || requestedUnit === 'м3') {
    volume = volumeInMl / 1000000;
    outputUnit = 'м³';
  }

  const roundedVolume = Number(volume.toFixed(4));

  // Если объём пришлось переводить из мл, показываем это в решении
  const volumeText =
    outputUnit !== 'мл'
      ? `${formatNumber(volumeInMl)} мл = ${formatNumber(roundedVolume)} ${outputUnit}`
      : `${formatNumber(roundedVolume)} мл`;

  results.push({
    id: `obyomP-${formula}`,
    formula,
    massaRastvora: mass,
    massaRastvoraUnit: rastvorRow.izmerenie || 'г',
    plotnost: density,
    plotnostUnit: densityRow.izmerenie || 'г/мл',
    obyom: roundedVolume,
    obyomUnit: outputUnit,
    text: `V(раствора) = m(раствора) / ρ = ${formatNumber(
      massInGrams
    )} г / ${formatNumber(density)} г/мл = ${volumeText}`,
  });

  return {
    results,
    errors,
  };
}